package com.vehicles;

public class Motorbike extends com.vehicles.Vehicle {


    //Declaration of the luggage box option that can be added to a Motorbike
    private boolean hasLuggageBox;

    //Constructor for the Motorbike
    public Motorbike(String make, String model, int yearOfManufacture, Gearbox gearbox, int vehicleIdentificationNumber, int mileage, String colour, boolean hasLuggageBox) {
        super(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour);
        this.hasLuggageBox = hasLuggageBox;
    }

    public boolean getHasLuggageBox() {
        return hasLuggageBox;
    }

    //Setter so that hasLuggageBox isn't final and the motorcycle option can be removed at any time, as per the assignment description
    public void setHasLuggageBox(boolean hasLuggageBox) {
        this.hasLuggageBox = hasLuggageBox;
    }

    //Method so that the details of the Vehicle can be displayed in the array of created Vehicles
    public String toString() {
        return "Motorbike - " +
                "make = " + make +
                ", model = " + model +
                ", year = " + yearOfManufacture +
                ", gearbox type = " + gearbox +
                ", colour = " + colour  +
                ", mileage = " + mileage +
                ", VIN = " + vehicleIdentificationNumber +
                ", hasLuggageBox = " + hasLuggageBox;

    }
}

