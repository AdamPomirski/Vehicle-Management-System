package com.vehicles;

public class Estate extends com.vehicles.Car {

    //Declaration of the third row seat option that can be added to an Estate Car
    private final boolean hasThirdRowSeat;

    //Constructor for the Estate Car
    public Estate(String make, String model, int yearOfManufacture, Gearbox gearbox, int vehicleIdentificationNumber, int mileage, String colour, boolean hasSatNav, boolean hasParkingSensors, boolean hasTowBar, boolean hasRoofRack, boolean hasThirdRowSeat) {
        super(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack);
        this.hasThirdRowSeat = hasThirdRowSeat;
    }

    //Method so that the details of the Vehicle can be displayed in the array of created Vehicles
    public String toString() {
        return "Car - Estate - " +
                "make = " + make +
                ", model = " + model +
                ", year = " + yearOfManufacture +
                ", gearbox type = " + gearbox +
                ", colour = " + colour  +
                ", mileage = " + mileage +
                ", VIN = " + vehicleIdentificationNumber +
                ", hasSatNav = " + hasSatNav +
                ", hasParkingSensors = " + hasParkingSensors +
                ", hasTowBar = " + hasTowBar +
                ", hasRoofRack = " + hasRoofRack +
                ", hasThirdRowSeat = " + hasThirdRowSeat;
    }

}
