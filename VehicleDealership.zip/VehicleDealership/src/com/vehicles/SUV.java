package com.vehicles;

public class SUV extends com.vehicles.Car {

    //Declaration of the AWD option that can be added to an SUV
    private final boolean hasAWD;

    //Constructor for the SUV
    public SUV(String make, String model, int yearOfManufacture, Gearbox gearbox, int vehicleIdentificationNumber, int mileage, String colour, boolean hasSatNav, boolean hasParkingSensors, boolean hasTowBar, boolean hasRoofRack, boolean hasAWD) {
        super(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack);
        this.hasAWD = hasAWD;
    }

    //Method so that the details of the Vehicle can be displayed in the array of created Vehicles
    public String toString() {
        return "Car - SUV - " +
                "make = " + make +
                ", model = " + model +
                ", year = " + yearOfManufacture +
                ", gearbox type = " + gearbox +
                ", colour = " + colour  +
                ", mileage = " + mileage +
                ", VIN = " + vehicleIdentificationNumber +
                ", hasSatNav = " + hasSatNav +
                ", hasParkingSensors = " + hasParkingSensors +
                ", hasTowBar = " + hasTowBar +
                ", hasRoofRack = " + hasRoofRack +
                ", hasAWD = " + hasAWD;
    }


}
