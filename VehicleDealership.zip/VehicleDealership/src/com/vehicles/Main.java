package com.vehicles;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //Creating the vehicle scanner object to take inputs from the user
        Scanner vehicleScanner = new Scanner(System.in);

        System.out.println("How many vehicles would you like to add to the system?");
        int numOfVehicles = vehicleScanner.nextInt();
        vehicleScanner.nextLine();

        //Array of created vehicles declaration
        Vehicle[] Vehicles = new Vehicle[numOfVehicles];

        //Beginning of while loop that follows logic of the sample activity diagram
        while (numOfVehicles > 0) {

            //Scanner used to assign data for creation of a car to variables in the Vehicle class
            System.out.println("Is the vehicle a Car or a Motorbike?");
            String vehicleType = vehicleScanner.nextLine();
            if (vehicleType.equals("Car")) {

                System.out.println("Please enter the make of the car: ");
                String make = vehicleScanner.nextLine();

                System.out.println("Please enter the model of the car: ");
                String model = vehicleScanner.nextLine();

                System.out.println("Please enter the year the car was manufactured: ");
                int yearOfManufacture = vehicleScanner.nextInt();
                vehicleScanner.nextLine();

                //Gearbox type of the Car as an enum
                System.out.println("Please enter the gearbox type of the car (MANUAL or AUTOMATIC): ");
                Vehicle.Gearbox gearbox = null;
                //Try catch statement used to ensure that the user has input the correct data, capitalises user's input to improve user experience and prevent errors from being thrown
                while (gearbox == null) {
                    try {
                        String gearboxInput = vehicleScanner.nextLine().toUpperCase();
                        gearbox = Vehicle.Gearbox.valueOf(gearboxInput);
                    } catch (IllegalArgumentException e) {
                        //Error message if user's input isn't valid
                        System.out.println("Invalid input. Please enter 'MANUAL' or 'AUTOMATIC': ");
                    }
                }

                System.out.println("Please enter the colour of the car: ");
                String colour = vehicleScanner.nextLine();

                System.out.println("Please enter the mileage of the car: ");
                int mileage = vehicleScanner.nextInt();
                vehicleScanner.nextLine();

                System.out.println("Please enter the VIN of the car: ");
                int vehicleIdentificationNumber = vehicleScanner.nextInt();
                vehicleScanner.nextLine();

                //Extra options that can be added to a Car in the form of a boolean value
                System.out.println("Does the car have Sat-Nav?" + "\n" + "Please enter your answer in the form of true or false: ");
                boolean hasSatNav = vehicleScanner.nextBoolean();
                vehicleScanner.nextLine();

                System.out.println("Does the car have Parking Sensors?" + "\n" + "Please enter your answer in the form of true or false: ");
                boolean hasParkingSensors = vehicleScanner.nextBoolean();
                vehicleScanner.nextLine();

                System.out.println("Does the car have a Tow Bar?" + "\n" + "Please enter your answer in the form of true or false: ");
                boolean hasTowBar = vehicleScanner.nextBoolean();
                vehicleScanner.nextLine();

                System.out.println("Does the car have a Roof Rack?" + "\n" + "Please enter your answer in the form of true or false: ");
                boolean hasRoofRack = vehicleScanner.nextBoolean();
                vehicleScanner.nextLine();

                //Decision carried out to create a car of the correct subclass of the Car class - SUV, Hatchback, Saloon or Estate
                System.out.println("Is the Car an SUV, Hatchback, Saloon or Estate? ");
                String carType = vehicleScanner.nextLine();

                //Switch statement to select which subclass of Car is created
                switch (carType) {
                    //Logic to carry out the creation of the SUV subclass of Car
                    case "SUV":
                        System.out.println("Does your car have AWD?"  + "\n" + "Please enter your answer in the form of true or false: ");
                        boolean hasAWD = vehicleScanner.nextBoolean();
                        Vehicles[Vehicles.length - numOfVehicles] = new SUV(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack, hasAWD);
                        vehicleScanner.nextLine();
                        break;
                    //Logic to carry out the creation of the Hatchback subclass of Car
                    case "Hatchback":
                        Vehicles[Vehicles.length - numOfVehicles] = new Hatchback(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack);
                        break;
                    //Logic to carry out the creation of the Saloon subclass of Car
                    case "Saloon":
                        Vehicles[Vehicles.length - numOfVehicles] = new Saloon(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack);
                        break;
                    //Logic to carry out the creation of the Estate subclass of Car
                    case "Estate":
                        System.out.println("Does your car have a third row seat?"  + "\n" + "Please enter your answer in the form of true or false: ");
                        boolean hasThirdRowSeat = vehicleScanner.nextBoolean();
                        Vehicles[Vehicles.length - numOfVehicles] = new Estate(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack, hasThirdRowSeat);
                        break;
                }
                //Else statement to select the creation of a Motorbike record
            } else {
                //Scanner used to assign data for creation of a Motorbike to variables in the Vehicle class
                System.out.println("Please enter the make of the Motorbike: ");
                String make = vehicleScanner.nextLine();

                System.out.println("Please enter the model of the Motorbike: ");
                String model = vehicleScanner.nextLine();

                System.out.println("Please enter the year Motorbike car was manufactured: ");
                int yearOfManufacture = vehicleScanner.nextInt();
                vehicleScanner.nextLine();

                System.out.println("Please enter the gearbox type of the Motorbike (MANUAL or AUTOMATIC): ");
                Vehicle.Gearbox gearbox = null;
                while (gearbox == null) {
                    //Try catch statement used to ensure that the user has input the correct data, capitalises user's input to improve user experience and prevent errors from being thrown
                    try {
                        String gearboxInput = vehicleScanner.nextLine().toUpperCase();
                        gearbox = Vehicle.Gearbox.valueOf(gearboxInput);
                    } catch (IllegalArgumentException e) {
                        //Error message if user's input isn't valid
                        System.out.println("Invalid input. Please enter 'MANUAL' or 'AUTOMATIC': ");
                    }
                }

                System.out.println("Please enter the colour of the Motorbike: ");
                String colour = vehicleScanner.nextLine();

                System.out.println("Please enter the mileage of the Motorbike: ");
                int mileage = vehicleScanner.nextInt();
                vehicleScanner.nextLine();

                System.out.println("Please enter the VIN of the Motorbike: ");
                int vehicleIdentificationNumber = vehicleScanner.nextInt();
                vehicleScanner.nextLine();

                //Extra option of a luggage box that can be added to and removed from a Motorbike in the form of a boolean value
                System.out.println("Does the Motorbike have a luggage box?" + "\n" + "Please enter your answer in the form of true or false: ");
                boolean hasLuggageBox = vehicleScanner.nextBoolean();
                vehicleScanner.nextLine();

                //Logic to add the newly created record of the Motorbike to the Vehicles array
                Vehicles[Vehicles.length - numOfVehicles] = new Motorbike(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasLuggageBox);
            }
            //Decrementing the number of vehicles so that the user is prompted to input the data for the correct amount of vehicles whilst they are in the while loop
            numOfVehicles--;
        }
        //Printing the entire Vehicles array to the console
            System.out.println(Arrays.toString(Vehicles));

        }
    }
