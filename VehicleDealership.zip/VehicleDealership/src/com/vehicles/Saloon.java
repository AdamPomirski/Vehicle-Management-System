package com.vehicles;

public class Saloon extends com.vehicles.Car {

    //Constructor for the Saloon
    public Saloon(String make, String model, int yearOfManufacture, Gearbox gearbox, int vehicleIdentificationNumber, int mileage, String colour, boolean hasSatNav, boolean hasParkingSensors, boolean hasTowBar, boolean hasRoofRack) {
        super(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour, hasSatNav, hasParkingSensors, hasTowBar, hasRoofRack);
    }

    //Method so that the details of the Vehicle can be displayed in the array of created Vehicles
    public String toString() {
        return "Car - Saloon - " +
                "make = " + make +
                ", model = " + model +
                ", year = " + yearOfManufacture +
                ", gearbox type = " + gearbox +
                ", colour = " + colour  +
                ", mileage = " + mileage +
                ", VIN = " + vehicleIdentificationNumber +
                ", hasSatNav = " + hasSatNav +
                ", hasParkingSensors = " + hasParkingSensors +
                ", hasTowBar = " + hasTowBar +
                ", hasRoofRack = " + hasRoofRack;
    }
}
