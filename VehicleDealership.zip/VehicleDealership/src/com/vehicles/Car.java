package com.vehicles;

public abstract class Car extends com.vehicles.Vehicle {

    //Extra options that can be fitted to cars
    final boolean hasSatNav;
    final boolean hasParkingSensors;
    final boolean hasTowBar;
    final boolean hasRoofRack;

    //Constructor for a Car
    public Car(String make, String model, int yearOfManufacture, Gearbox gearbox, int vehicleIdentificationNumber, int mileage, String colour, boolean hasSatNav, boolean hasParkingSensors, boolean hasTowBar, boolean hasRoofRack) {
        super(make, model, yearOfManufacture, gearbox, vehicleIdentificationNumber, mileage, colour);
        this.hasSatNav = hasSatNav;
        this.hasParkingSensors = hasParkingSensors;
        this.hasTowBar = hasTowBar;
        this.hasRoofRack = hasRoofRack;

    }


}
