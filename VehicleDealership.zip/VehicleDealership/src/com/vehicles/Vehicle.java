package com.vehicles;

public abstract class Vehicle {
//Declaration of vehicle features

    //Gearbox enum has been used as there are only 2 potential options, for simplicity an enum has been used instead of a string
    public enum Gearbox {
        MANUAL, AUTOMATIC
    }

    //Immutable fields
    final String make;
    final String model;
    final int yearOfManufacture;
    final Gearbox gearbox;
    final int vehicleIdentificationNumber;

    //Mutable fields
    int mileage;
    String colour;

    //Constructor for a Vehicle
    public Vehicle(String make, String model, int yearOfManufacture, Gearbox gearbox, int vehicleIdentificationNumber, int mileage, String colour) {
        this.make = make;
        this.model = model;
        this.yearOfManufacture = yearOfManufacture;
        this.gearbox = gearbox;
        this.vehicleIdentificationNumber = vehicleIdentificationNumber;
        this.mileage = mileage;
        this.colour = colour;
    }

}
